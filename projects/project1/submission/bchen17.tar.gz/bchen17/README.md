Name: Brian Chen
BU-ID: bchen17
B-Number: 01007106

All the traces work. 